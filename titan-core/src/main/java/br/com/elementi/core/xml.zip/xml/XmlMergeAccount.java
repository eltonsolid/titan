package br.com.elementi.core.xml;

public class XmlMergeAccount {

	public static void merge(XmlUpdateAccount updateAccount, Account account) {

	}

}
