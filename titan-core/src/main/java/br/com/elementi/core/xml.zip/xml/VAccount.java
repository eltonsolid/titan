package br.com.elementi.core.xml;

public class VAccount {
}
