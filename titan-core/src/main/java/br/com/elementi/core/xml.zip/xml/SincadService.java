package br.com.elementi.core.xml;

import com.google.common.collect.Lists;

import java.util.List;

/**
 * Created by eltonsolid on 10/06/17.
 */
public class SincadService {

    public List<XmlEvent> listEvents() {
        return Lists.newArrayList();
    }
}
