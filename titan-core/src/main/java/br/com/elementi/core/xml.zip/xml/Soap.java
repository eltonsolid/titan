package br.com.elementi.core.xml;

public class Soap {

	public static <T> T create(Class<T> classe, String dinwebservice) {
		return null;
	}

	public static <T> T server(T server, String dinServerwebservice) {
		return null;
	}

}
