@XmlSchema(
		xmlns = {
		@XmlNs(prefix = "xsi",	namespaceURI = "http://www.w3.org/2001/XMLSchema-instance")
		},
		elementFormDefault = XmlNsForm.UNQUALIFIED)
package br.com.elementi.core.xml;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;
