package br.com.elementi.core.xml;

public class XmlValidateException extends RuntimeException {

	public XmlValidateException(String value) {
		super(value);
	}
}
