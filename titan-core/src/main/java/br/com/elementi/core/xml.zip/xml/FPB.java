package br.com.elementi.core.xml;

public class FPB {

	public void call(String fileResponse) {

	}

}
