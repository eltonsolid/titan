package br.com.elementi.core.xml;

public class XmlConstraint {

	public static void applay(Account account) {

	}

}
