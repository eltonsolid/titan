package br.com.elementi.core.xml;

public class Parameter {

	public static Parameter load() {
		// TODO Auto-generated method stub
		return null;
	}

	public String dinwebservice() {
		return null;
	}

	public String fpbwebservice() {
		return null;
	}

	public String dinWebServicePublisher() {
		// TODO Auto-generated method stub
		return null;
	}

	public String fpbWebServicePublisher() {
		// TODO Auto-generated method stub
		return null;
	}

}
