package br.com.elementi.core.xml;

public class AccountRepository {

	public Account findAccount(String operationalCode, String accountNumber) {

		return null;
	}

	public void executeRules(Account account) {

	}

	public void insertAccount(Account account) {

	}
	public void updateAccount(Account account) {
		
	}
}
