package br.com.elementi.core.xml;

import java.util.List;

public class BVBG_001 {

    private SincadService service;

    public BVBG_001(SincadService service) {
        this.service = service;
    }

    public static BVBG_001 with(SincadService service) {
        return new BVBG_001(service);
    }

    public XmlFile open(XmlFile receive) {
        XmlFile response = XmlFile.accountRespose(receive.creator());
        try {
            fileControll(receive);
            process(response, receive);
        } catch (Exception exception) {
            handleFatal(response, exception);
        }
        return response;
    }

    private void insertEntityOwner(XmlFile receive) {
        for (XmlBizGrp grp : receive.getBizGrp()) {
            XmlDocument document = null;//getDocument(grp);

        }
    }

    private XmlDocument getDocumentDefault(XmlBizGrp bizGrp) {
        /*if (bizGrp.body.createAccount.accountOwner.individual != null) {
            return getDocumentDefault(bizGrp.body.createAccount.accountOwner.individual.documents);
        }
        if(bizGrp.body.createAccount.accountOwner.organization!= null){
            return getDocumentDefault(bizGrp.body.createAccount.accountOwner.organization);
        }*/

        return null;
    }

    private XmlDocument getDocumentDefault(List<XmlDocument> documents) {
        for (XmlDocument document : documents) {

        }
        return null;
    }


    public void handleFatal(XmlFile response, Exception exception) {
          exception.printStackTrace();

    }

    private void process(XmlFile response, XmlFile receive) {
        for (XmlBizGrp bizGrp : receive.getBizGrp()) {
            response.add(process(bizGrp));
        }

    }

    private XmlBizGrp process(XmlBizGrp bizGrp) {
        try {
            xsd(bizGrp);
            polices(bizGrp);
            XmlDetailAccount detailAccount = insert(bizGrp);
            return XmlBizGrp.create(bizGrp.header, detailAccount);
        } catch (Exception exception) {
            return handle(bizGrp.header, exception);
        }
    }

    private XmlDetailAccount insert(XmlBizGrp bizGrp) {
        bizGrp.body.createAccount;
        return null;
    }

    private XmlBizGrp handle(XmlHeader header, Exception exception) {
        return exception instanceof XmlException ? erro(header, ((XmlException) exception)) : erro(header, exception);
    }


    private XmlBizGrp erro(XmlHeader header, Exception exception) {
        String description = exception.getMessage() == null ? exception.getClass().getName() : exception.getMessage();
        return erro(header, new XmlException("999", description));
    }

    private XmlBizGrp erro(XmlHeader header, XmlException exception) {
        exception.printStackTrace();
        XmlErro erro = XmlErro.create(header);
        for (XmlException.Value value : exception.values) {
            erro.add(value.code, value.description);
        }
        return XmlBizGrp.create(header, erro);
    }


    private void polices(XmlBizGrp receive) {

    }

    private void xsd(XmlBizGrp receive) {

    }

    private void fileControll(XmlFile receive) {

    }


}
