package br.com.elementi.core.xml;

import br.com.elementi.core.xml.XmlResolver.XmlFileOperation;

import java.util.TimerTask;

/**
 * Created by eltonsolid on 07/09/17.
 */
public class Consumer extends TimerTask {

    FPB fpb;
    SincadService service;
    String receivePath = "./Performance/";
    String responsePath = "./output/";

    public Consumer(SincadService service) {
        this.service = service;
    }

    @Override
    public void run() {
        for (XmlEvent event : service.listEvents()) {
            try {
                XmlFile fileReceive = read(event);
                XmlFile fileResponse = process(fileReceive);
                write(fileResponse);
                fpb(fileResponse);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }

    public XmlFile process(XmlFile xmlFile) throws Exception {
        XmlFileOperation operation = XmlResolver.operation(xmlFile.creator());
        switch (operation) {
            case ACCOUNT_INSERT:
                return accountInsert(xmlFile);
            case ACCOUNT_UPDATE:
                return accountUpdate(xmlFile);
            case ACCOUNT_DETAIL:
                return accountDetail(xmlFile);
            case ACCOUNT_HASH:
                return hash(xmlFile);
            case LINK_INSERT_UPDATE:
                return linkInsertUpdate(xmlFile);
            case LINK_DETAIL:
                return linkDetail(xmlFile);
            default:
                return XmlFile.erro(xmlFile.creator());
        }
    }

    public void fpb(XmlFile fileResponse) {
        fpb.call(responsePath + fileResponse.fileName());
    }

    public void write(XmlFile fileResponse) throws Exception {
        Xml.write(fileResponse, responsePath + fileResponse.fileName());
    }

    public XmlFile read(XmlEvent event) throws Exception {
        return Xml.read(receivePath + event.getFile());
    }

    private XmlFile accountInsert(XmlFile fileReceive) {
        BVBG_001.with(service).open(fileReceive);



        XmlFile response = XmlFile.accountRespose(fileReceive.creator());
        for (XmlBizGrp bizGrp : fileReceive.getBizGrp()) {
            response.add(new XmlProcessAccount().insert(bizGrp));
        }
        return response;
    }

    private XmlFile accountUpdate(XmlFile fileReceive) {
        XmlFile response = XmlFile.accountRespose(fileReceive.creator());
        for (XmlBizGrp bizGrp : fileReceive.getBizGrp()) {
            response.add(new XmlProcessAccount().update(bizGrp));
        }
        return response;
    }

    private XmlFile accountDetail(XmlFile fileReceive) {
        XmlFile response = XmlFile.accountRespose(fileReceive.creator());
        for (XmlBizGrp bizGrp : fileReceive.getBizGrp()) {
            response.add(new XmlProcessAccount().update(bizGrp));
        }
        return response;
    }

    private XmlFile hash(XmlFile fileReceive) {
        XmlFile response = XmlFile.hash(fileReceive.creator());
        for (XmlBizGrp bizGrp : fileReceive.getBizGrp()) {
            response.add(XmlProcessAccount.hash(bizGrp));
        }
        return response;
    }

    private XmlFile linkInsertUpdate(XmlFile fileReceive) {
        XmlFile response = XmlFile.link(fileReceive.creator());
        for (XmlBizGrp bizGrp : fileReceive.getBizGrp()) {
            response.add(new XmlProcessAccount().update(bizGrp));
        }
        return response;
    }

    private XmlFile linkDetail(XmlFile fileReceive) {
        XmlFile response = XmlFile.link(fileReceive.creator());
        for (XmlBizGrp bizGrp : fileReceive.getBizGrp()) {
            response.add(new XmlProcessAccount().update(bizGrp));
        }
        return response;
    }


}
