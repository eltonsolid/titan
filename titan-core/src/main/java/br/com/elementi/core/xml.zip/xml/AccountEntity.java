package br.com.elementi.core.xml;

/**
 * Created by eltonsolid on 10/06/17.
 */
public class AccountEntity {
}
