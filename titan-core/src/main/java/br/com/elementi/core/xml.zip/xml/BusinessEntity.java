package br.com.elementi.core.xml;

public class BusinessEntity {

	private Integer code;

	public Integer getCode() {
		return code;
	}

}
