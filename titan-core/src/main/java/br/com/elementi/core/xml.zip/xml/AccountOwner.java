package br.com.elementi.core.xml;

public class AccountOwner {

	private Integer entity;

	private Integer entityParticipant;

}
