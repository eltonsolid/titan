package br.com.elementi.core.xml;

public class DIN {

	public void call(String fileResponse) {

	}

}
